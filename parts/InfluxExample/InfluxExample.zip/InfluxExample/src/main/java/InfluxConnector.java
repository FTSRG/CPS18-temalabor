

import java.sql.Date;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.influxdb.BatchOptions;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.influxdb.impl.InfluxDBResultMapper;

public class InfluxConnector {
 private static String InfluxURL = "http://grafana.wlap.eu:8086";
 private static String InfluxUser = "CPSin";
 private static String InfluxPass = "LaborImage";
 private static String InfluxDBname = "CPS";
 
 InfluxDB databaseConnection;
 
 public InfluxConnector() {

 databaseConnection = InfluxDBFactory.connect(InfluxURL, InfluxUser, InfluxPass);
 databaseConnection.setDatabase(InfluxDBname);
 databaseConnection.enableBatch(BatchOptions.DEFAULTS);

 }
 public void addData(String name, String timestamp, double accX, double accY, double accZ) {
	 
 databaseConnection.write(
 Point.measurement("gyro")
 
            .time( Long.valueOf(timestamp), TimeUnit.MILLISECONDS)
            .tag("name", name)
            .addField("accX", accX)
            .addField("accY", accY)
            .addField("accZ", accZ)
            .build());
 }

}